package com.zheng.studentmanagementsystem.model;

import javafx.beans.property.*;

import java.time.LocalDate;

public class Student {

    private final SimpleStringProperty studentId;
    private final SimpleStringProperty name;
    private final SimpleStringProperty gender;
    private final SimpleStringProperty idNumber;
    private final ObjectProperty<LocalDate> birthDate;
    private final SimpleStringProperty className;
    private final SimpleStringProperty phoneNumber;

    public Student(String studentId, String name, String gender, String idNumber, LocalDate birthDate, String className, String phoneNumber) {
        this.studentId = new SimpleStringProperty(studentId);
        this.name = new SimpleStringProperty(name);
        this.gender = new SimpleStringProperty(gender);
        this.idNumber = new SimpleStringProperty(idNumber);
        this.birthDate = new SimpleObjectProperty<>(birthDate);
        this.className = new SimpleStringProperty(className);
        this.phoneNumber = new SimpleStringProperty(phoneNumber);
    }

    public String getStudentId() {
        return studentId.get();
    }

    public void setStudentId(String studentId) {
        this.studentId.set(studentId);
    }

    public StringProperty studentIdProperty() {
        return studentId;
    }

    public String getName() {
        return name.get();
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public StringProperty nameProperty() {
        return name;
    }

    public String getGender() {
        return gender.get();
    }

    public void setGender(String gender) {
        this.gender.set(gender);
    }

    public StringProperty genderProperty() {
        return gender;
    }

    public String getIdNumber() {
        return idNumber.get();
    }

    public void setIdNumber(String idNumber) {
        this.idNumber.set(idNumber);
    }

    public StringProperty idNumberProperty() {
        return idNumber;
    }

    public LocalDate getBirthDate() {
        return birthDate.get();
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate.set(birthDate);
    }

    public ObjectProperty<LocalDate> birthDateProperty() {
        return birthDate;
    }

    public String getClassName() {
        return className.get();
    }

    public void setClassName(String className) {
        this.className.set(className);
    }

    public StringProperty classNameProperty() {
        return className;
    }

    public String getPhoneNumber() {
        return phoneNumber.get();
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber.set(phoneNumber);
    }

    public StringProperty phoneNumberProperty() {
        return phoneNumber;
    }
}



