package com.zheng.studentmanagementsystem.controller;

import com.zheng.studentmanagementsystem.model.Student;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class SearchStudentController {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/student_management?allowPublicKeyRetrieval=true&useSSL=false";
    private static final String USER = "root";
    private static final String PASSWORD = "123456";

    private Connection connection;

    @FXML
    private TextField txtSearch;
    @FXML
    private TableView<Student> tblStudents;
    @FXML
    private TableColumn<Student, String> colStudentId;
    @FXML
    private TableColumn<Student, String> colName;
    @FXML
    private TableColumn<Student, String> colGender;
    @FXML
    private TableColumn<Student, String> colIdNumber;
    @FXML
    private TableColumn<Student, LocalDate> colBirthDate;
    @FXML
    private TableColumn<Student, String> colClassName;
    @FXML
    private TableColumn<Student, String> colPhoneNumber;
    @FXML
    private Button btnSearch;
    @FXML
    private Button btnImport;
    @FXML
    private Button btnBack;

    @FXML
    private void initialize() {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the database
            connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        // 设置表格列标题
        colStudentId.setCellValueFactory(cellData -> cellData.getValue().studentIdProperty());
        colName.setCellValueFactory(cellData -> cellData.getValue().nameProperty());
        colGender.setCellValueFactory(cellData -> cellData.getValue().genderProperty());
        colIdNumber.setCellValueFactory(cellData -> cellData.getValue().idNumberProperty());
        colBirthDate.setCellValueFactory(cellData -> cellData.getValue().birthDateProperty());
        colClassName.setCellValueFactory(cellData -> cellData.getValue().classNameProperty());
        colPhoneNumber.setCellValueFactory(cellData -> cellData.getValue().phoneNumberProperty());

        btnSearch.setOnAction(event -> searchStudents());
        btnImport.setOnAction(event -> importStudentsFromFile());
        btnBack.setOnAction(event -> loadMainPage());

        // 自动显示所有学生信息
        searchStudents();
    }

    private void searchStudents() {
        String keyword = txtSearch.getText();
        ObservableList<Student> students = FXCollections.observableArrayList();

        try {
            PreparedStatement preparedStatement;
            if (keyword.isEmpty()) {
                preparedStatement = connection.prepareStatement("SELECT * FROM students");
            } else {
                preparedStatement = connection.prepareStatement("SELECT * FROM students WHERE student_id LIKE ? OR name LIKE ? OR id_number LIKE ? OR class_name LIKE ? OR phone_number LIKE ?");
                preparedStatement.setString(1, "%" + keyword + "%");
                preparedStatement.setString(2, "%" + keyword + "%");
                preparedStatement.setString(3, "%" + keyword + "%");
                preparedStatement.setString(4, "%" + keyword + "%");
                preparedStatement.setString(5, "%" + keyword + "%");
            }
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                Student student = new Student(
                        resultSet.getString("student_id"),
                        resultSet.getString("name"),
                        resultSet.getString("gender"),
                        resultSet.getString("id_number"),
                        resultSet.getDate("birth_date").toLocalDate(),
                        resultSet.getString("class_name"),
                        resultSet.getString("phone_number")
                );
                students.add(student);
            }

            tblStudents.setItems(students);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "数据库错误", "无法搜索学生记录。");
        }
    }

    private void importStudentsFromFile() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("选择CSV文件");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV Files", "*.csv"));
        File selectedFile = fileChooser.showOpenDialog(btnImport.getScene().getWindow());

        if (selectedFile != null) {
            List<Student> studentsToInsert = readStudentsFromCSV(selectedFile.getAbsolutePath());

            for (Student student : studentsToInsert) {
                try {
                    PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO students (student_id, name, gender, id_number, birth_date, class_name, phone_number) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    preparedStatement.setString(1, student.getStudentId());
                    preparedStatement.setString(2, student.getName());
                    preparedStatement.setString(3, student.getGender());
                    preparedStatement.setString(4, student.getIdNumber());
                    preparedStatement.setDate(5, java.sql.Date.valueOf(student.getBirthDate()));
                    preparedStatement.setString(6, student.getClassName());
                    preparedStatement.setString(7, student.getPhoneNumber());

                    preparedStatement.executeUpdate();
                } catch (SQLException e) {
                    e.printStackTrace();
                    showAlert(Alert.AlertType.ERROR, "数据库错误", "无法插入学生记录：" + student.getStudentId());
                }
            }

            showAlert(Alert.AlertType.INFORMATION, "成功", "学生记录已成功导入。");
            searchStudents(); // 刷新表格数据
        }
    }

    private List<Student> readStudentsFromCSV(String filePath) {
        List<Student> students = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            boolean isFirstLine = true; // Skip header line
            while ((line = br.readLine()) != null) {
                if (isFirstLine) {
                    isFirstLine = false;
                    continue;
                }
                String[] values = line.split(",");
                if (values.length >= 7) {
                    Student student = new Student(
                            values[0],
                            values[1],
                            values[2],
                            values[3],
                            LocalDate.parse(values[4]),
                            values[5],
                            values[6]
                    );
                    students.add(student);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "文件错误", "无法读取CSV文件。");
        }
        return students;
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void loadMainPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Main.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnBack.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}



