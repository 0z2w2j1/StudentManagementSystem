package com.zheng.studentmanagementsystem.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class EditStudentController {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/student_management?allowPublicKeyRetrieval=true&useSSL=false";
    private static final String USER = "root";
    private static final String PASSWORD = "123456";

    private Connection connection;

    @FXML
    private TextField txtStudentId;
    @FXML
    private TextField txtName;
    @FXML
    private ComboBox<String> cmbGender;
    @FXML
    private TextField txtIdNumber;
    @FXML
    private DatePicker dpBirthDate;
    @FXML
    private TextField txtClassName;
    @FXML
    private TextField txtPhoneNumber;
    @FXML
    private Button btnSearch;
    @FXML
    private Button btnSave;
    @FXML
    private Button btnCancel;
    @FXML
    private Button btnReturn;

    @FXML
    private void initialize() {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the database
            connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }

        // 设置性别选项
        cmbGender.getItems().addAll("男", "女");

        btnSearch.setOnAction(event -> searchStudent());
        btnSave.setOnAction(event -> updateStudent());
        btnCancel.setOnAction(event -> clearFields());
        btnReturn.setOnAction(event -> loadMainPage());
    }

    private void searchStudent() {
        String studentId = txtStudentId.getText();
        if (studentId.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "输入错误", "请输入学生ID。");
            return;
        }

        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM students WHERE student_id = ?");
            preparedStatement.setString(1, studentId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                txtName.setText(resultSet.getString("name"));
                cmbGender.setValue(resultSet.getString("gender"));
                txtIdNumber.setText(resultSet.getString("id_number"));
                dpBirthDate.setValue(resultSet.getDate("birth_date").toLocalDate());
                txtClassName.setText(resultSet.getString("class_name"));
                txtPhoneNumber.setText(resultSet.getString("phone_number"));
            } else {
                showAlert(Alert.AlertType.INFORMATION, "未找到", "没有找到对应的学生记录。");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "数据库错误", "无法搜索学生记录。");
        }
    }

    private void updateStudent() {
        String studentId = txtStudentId.getText();
        String name = txtName.getText();
        String gender = cmbGender.getValue();
        String idNumber = txtIdNumber.getText();
        LocalDate birthDate = dpBirthDate.getValue();
        String className = txtClassName.getText();
        String phoneNumber = txtPhoneNumber.getText();

        if (studentId.isEmpty() || name.isEmpty() || gender == null || idNumber.isEmpty() || birthDate == null || className.isEmpty() || phoneNumber.isEmpty()) {
            showAlert(Alert.AlertType.WARNING, "输入错误", "所有字段都必须填写。");
            return;
        }

        try {
            PreparedStatement preparedStatement = connection.prepareStatement("UPDATE students SET name = ?, gender = ?, id_number = ?, birth_date = ?, class_name = ?, phone_number = ? WHERE student_id = ?");
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, gender);
            preparedStatement.setString(3, idNumber);
            preparedStatement.setDate(4, java.sql.Date.valueOf(birthDate));
            preparedStatement.setString(5, className);
            preparedStatement.setString(6, phoneNumber);
            preparedStatement.setString(7, studentId);

            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows > 0) {
                showAlert(Alert.AlertType.INFORMATION, "成功", "学生信息已成功更新。");
                clearFields();
            } else {
                showAlert(Alert.AlertType.INFORMATION, "未找到", "没有找到对应的学生记录。");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "数据库错误", "无法更新学生记录。");
        }
    }

    private void closeWindow() {
        Stage stage = (Stage) btnSave.getScene().getWindow();
        stage.close();
    }

    private void clearFields() {
        txtStudentId.clear();
        txtName.clear();
        cmbGender.setValue(null);
        txtIdNumber.clear();
        dpBirthDate.setValue(null);
        txtClassName.clear();
        txtPhoneNumber.clear();
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void loadMainPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Main.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnReturn.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "错误", "无法加载主界面。");
        }
    }
}



