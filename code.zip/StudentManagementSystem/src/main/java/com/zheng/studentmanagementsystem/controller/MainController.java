package com.zheng.studentmanagementsystem.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class MainController {

    @FXML
    private Button btnAddStudent;
    @FXML
    private Button btnEditStudent;
    @FXML
    private Button btnDeleteStudent;
    @FXML
    private Button btnSearchStudent;

    @FXML
    private void initialize() {
        btnAddStudent.setOnAction(event -> loadPage("/view/AddStudent.fxml"));
        btnEditStudent.setOnAction(event -> loadPage("/view/EditStudent.fxml"));
        btnDeleteStudent.setOnAction(event -> loadPage("/view/DeleteStudent.fxml"));
        btnSearchStudent.setOnAction(event -> loadPage("/view/SearchStudent.fxml"));
    }

    private void loadPage(String fxmlPath) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();
            Stage stage = (Stage) btnAddStudent.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}



