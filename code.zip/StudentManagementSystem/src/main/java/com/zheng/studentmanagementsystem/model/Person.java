package com.zheng.studentmanagementsystem.model;

public class Person {
    private String name;
    private String gender;
    private String idNumber;
    private Date birthDate;

    public Person(String name, String gender, String idNumber, Date birthDate) {
        this.name = name;
        this.gender = gender;
        this.idNumber = idNumber;
        this.birthDate = birthDate;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }
}



