package com.zheng.studentmanagementsystem.controller;

import com.zheng.studentmanagementsystem.model.Student;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

public class AddStudentController {

    private static final Logger logger = LoggerFactory.getLogger(AddStudentController.class);

    @FXML
    private TextField txtStudentId;
    @FXML
    private TextField txtName;
    @FXML
    private ComboBox<String> cmbGender;
    @FXML
    private TextField txtIdNumber;
    @FXML
    private DatePicker dpBirthDate;
    @FXML
    private TextField txtClassName;
    @FXML
    private TextField txtPhoneNumber;
    @FXML
    private Button btnSave;
    @FXML
    private Button btnCancel;
    @FXML
    private Button btnReturn;

    private Connection connection;

    @FXML
    private void initialize() {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the database
            String url = "jdbc:mysql://localhost:3306/student_management?allowPublicKeyRetrieval=true&useSSL=false";
            String user = "root";
            String password = "123456";
            connection = DriverManager.getConnection(url, user, password);
            logger.info("Database connection established successfully.");
        } catch (ClassNotFoundException e) {
            logger.error("MySQL JDBC driver not found.", e);
        } catch (SQLException e) {
            logger.error("Error connecting to the database", e);
        }

        // 设置性别选项
        cmbGender.getItems().addAll("男", "女");

        btnSave.setOnAction(event -> addStudent());
        btnCancel.setOnAction(event -> clearFields());
        btnReturn.setOnAction(event -> loadMainPage());
    }

    private void addStudent() {
        if (connection == null) {
            logger.error("Database connection is null.");
            return;
        }

        String studentId = txtStudentId.getText();
        String name = txtName.getText();
        String gender = cmbGender.getValue();
        String idNumber = txtIdNumber.getText();
        LocalDate birthDate = dpBirthDate.getValue();
        String className = txtClassName.getText();
        String phoneNumber = txtPhoneNumber.getText();

        if (studentId.isEmpty() || name.isEmpty() || gender == null || idNumber.isEmpty() || birthDate == null || className.isEmpty() || phoneNumber.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("输入错误");
            alert.setHeaderText(null);
            alert.setContentText("所有字段都必须填写。");
            alert.showAndWait();
            return;
        }

        try {
            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO students (student_id, name, gender, id_number, birth_date, class_name, phone_number) VALUES (?, ?, ?, ?, ?, ?, ?)");
            preparedStatement.setString(1, studentId);
            preparedStatement.setString(2, name);
            preparedStatement.setString(3, gender);
            preparedStatement.setString(4, idNumber);
            preparedStatement.setDate(5, java.sql.Date.valueOf(birthDate));
            preparedStatement.setString(6, className);
            preparedStatement.setString(7, phoneNumber);

            int affectedRows = preparedStatement.executeUpdate();
            if (affectedRows > 0) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("成功");
                alert.setHeaderText(null);
                alert.setContentText("学生信息已成功添加。");
                alert.showAndWait();

                // Clear input fields
                clearFields();
            }
        } catch (SQLException e) {
            logger.error("Error adding student to the database", e);
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("错误");
            alert.setHeaderText(null);
            alert.setContentText("无法添加学生信息。请检查输入并重试。");
            alert.showAndWait();
        }
    }

    private void clearFields() {
        txtStudentId.clear();
        txtName.clear();
        cmbGender.setValue(null);
        txtIdNumber.clear();
        dpBirthDate.setValue(null);
        txtClassName.clear();
        txtPhoneNumber.clear();
    }

    private void loadMainPage() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/Main.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) btnReturn.getScene().getWindow();
            stage.setScene(new Scene(root));
        } catch (IOException e) {
            logger.error("Error loading Main.fxml", e);
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("错误");
            alert.setHeaderText(null);
            alert.setContentText("无法加载主界面。");
            alert.showAndWait();
        }
    }
}



