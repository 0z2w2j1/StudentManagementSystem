module com.zheng.studentmanagementsystem {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires javafx.swing;
    requires javafx.media;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires eu.hansolo.tilesfx;
    requires com.almasb.fxgl.all;
    requires java.sql;
    requires org.slf4j;
    requires java.desktop;
    requires mysql.connector.j;

    opens com.zheng.studentmanagementsystem to javafx.fxml;
    exports com.zheng.studentmanagementsystem;
    exports com.zheng.studentmanagementsystem.controller;
    exports com.zheng.studentmanagementsystem.model;
    exports com.zheng.studentmanagementsystem.view;

    opens com.zheng.studentmanagementsystem.controller to javafx.fxml;
    opens com.zheng.studentmanagementsystem.model to javafx.base, javafx.controls;
}



