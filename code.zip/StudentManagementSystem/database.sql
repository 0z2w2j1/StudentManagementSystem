CREATE DATABASE IF NOT EXISTS student_management;

USE student_management;

CREATE TABLE IF NOT EXISTS students (
                                        id INT AUTO_INCREMENT PRIMARY KEY,
                                        student_id VARCHAR(10) UNIQUE NOT NULL,
                                        name VARCHAR(50) NOT NULL,
                                        gender ENUM('男', '女') NOT NULL,
                                        id_number VARCHAR(18) UNIQUE NOT NULL,
                                        birth_date DATE NOT NULL,
                                        class_name VARCHAR(50) NOT NULL,
                                        phone_number VARCHAR(15) NOT NULL
);